import ContactForm from '@/components/Common/ContactForm'
import React from 'react'

const page = () => {
  return (
    <main>
        <section>
            
        </section>
        <section>
            <ContactForm/>
        </section>
    </main>
  )
}

export default page