import React from 'react'

const page = async () => {
  return (
    <main></main>
  )
}

export default page