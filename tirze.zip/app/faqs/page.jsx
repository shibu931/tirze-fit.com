import React from 'react'

const page = () => {
  return (
    <main></main>
  )
}

export default page